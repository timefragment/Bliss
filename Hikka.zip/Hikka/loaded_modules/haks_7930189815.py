from .. import loader, utils
import asyncio
import random
from telethon.tl.types import Message

@loader.tds
class haks(loader.Module):
    """hacks версия beta 2.3"""

    strings = {
        "name": "hack",
        "command_disabled": "Команда отключена.",
    }

    def __init__(self):
        self.config = loader.ModuleConfig(
            loader.ConfigValue("hack1_emoji", "😈", "Эмодзи для команды hack1"),
            loader.ConfigValue("anic_text", "играли два шахматист,    один говорит ты че такой грустный,   а второй говорит да дед коня двинул,   😂🤣😂🤣🤣🤣😂🤣😂,   знаете как называют кофе без воды,  африкано,   😂🤣😂🤣😂🤣😂🤣😂🤣😂", "анекдоты для команды ani"),
            loader.ConfigValue("hack1_text", "взлом пентагона...,ищю базу с паролем и логином 10%,нашол базу вход в аккаунт 20%,поиск интересной инфы 40%,инфа про приступность 60%,инфа о динозаврах 70%,инфа о алкашах 80%,инфа о ждуль 90%,инфа о бомжах 90%,инфа о насикомых 100%,найдены данные что человек искавший интересную инфу дибил", "Текст для команды hack1 (через запятую)"),
            loader.ConfigValue("hacky_emoji", "😈", "Эмодзи для команды hacky"),
            loader.ConfigValue("hacky_text", "взлом оценок,......,ищю Логин от дневника 30%,ищю пароль от дневника 60%,ищю оценки 70%,исправляю русский 80%,исправляю информатику 90%,исправляю английский 100%,исправлено все на 5,шутка И вообще исправляю сам,доступ закрыт", "Текст для команды hacky (через запятую)"),
            loader.ConfigValue("gays_emoji", "😈", "Эмодзи для команды gays"),
            loader.ConfigValue("gays_text", "проверка на ты гей или нет,......,загрузка. 30%,загрузка.. 60%,загрузка... 70%,загрузка. 80%,загрузка.. 90%,загрузка... 100%,проверка...,ты гей или нет....,️ответ: ", "Текст для команды gays (через запятую)"),
        )

    async def client_ready(self, client, db):
        self.client = client
        
    async def anicmd(self, message: Message):
        """анекдоты"""
        text = self.config["anic_text"].split(",")
        sentences = [f"анекдот | {sentence.strip()}" for sentence in text]

        for sentence in sentences:
            message = await utils.answer(message, sentence)
            await asyncio.sleep(2)

    async def hack1cmd(self, message: Message):
        """взлом пентагона"""
        emoji = self.config["hack1_emoji"]
        text = self.config["hack1_text"].split(",")
        sentences = [f"{emoji} | {sentence.strip()}" for sentence in text]

        for sentence in sentences:
            message = await utils.answer(message, sentence)
            await asyncio.sleep(2)

    async def hackycmd(self, message: Message):
        """взлом оценнок"""
        emoji = self.config["hacky_emoji"]
        text = self.config["hacky_text"].split(",")
        sentences = [f"{emoji} | {sentence.strip()}" for sentence in text]

        for sentence in sentences:
            message = await utils.answer(message, sentence)
            await asyncio.sleep(2)

    async def com(self, message: Message, crm, emoji, text):
        sentences = [f"{emoji} | {sentence.strip()}" for sentence in text]

        for sentence in sentences:
            message = await utils.answer(message, sentence)
            await asyncio.sleep(2)

    async def gayscmd(self, message: Message):
        """команда проверки на гея"""
        emoji = self.config["gays_emoji"]
        text = self.config["gays_text"].split(",")
        pvc = random.randint(1, 2)
        if pvc == 1:
            crm = "да"
        else:
            crm = "нет"
        gays_text = [sentence.replace("️ответ: ", f"️ответ: {crm}") for sentence in text]
        await self.com(message, crm, emoji, gays_text)